import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message)

    try {
        def props     = message.getProperties()
        def exception = props.get("CamelExceptionCaught")

        def errorMsg     = exception?.getMessage() ?: "Error desconocido"
        def errorClass   = exception?.getClass()?.getName() ?: "UnknownException"
        def errorDetails = "${errorClass}: ${errorMsg}\n"

        if (exception != null) {
            errorDetails += exception.getStackTrace()
                .take(10)
                .collect { "  at ${it}" }
                .join("\n")
        }

        messageLog.addAttachmentAsString("Error_Details", errorDetails, "text/plain")
        messageLog.setStringProperty("ErrorClass",   errorClass)
        messageLog.setStringProperty("ErrorMessage", errorMsg)

        def ts = new Date().format("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", TimeZone.getTimeZone("UTC"))
        def errResponse = '{"status":"error","message":"' + errorMsg + '","timestamp":"' + ts + '"}'
        message.setBody(errResponse)
        message.setHeader("Content-Type", "application/json")

    } catch (Exception e) {
        message.setBody('{"status":"error","message":"Error en handler de errores"}')
        message.setHeader("Content-Type", "application/json")
    }

    return message
}
