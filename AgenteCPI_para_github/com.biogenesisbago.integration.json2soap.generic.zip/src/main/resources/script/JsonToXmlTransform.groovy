import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.xml.MarkupBuilder

def Message processData(Message message) {
    def body = message.getBody(String)

    def json   = new JsonSlurper().parseText(body)
    def writer = new StringWriter()
    def xml    = new MarkupBuilder(writer)

    xml.root {
        buildXmlFromJson(xml, json, "root")
    }

    def xmlStr = '<?xml version="1.0" encoding="UTF-8"?>' + writer.toString()
    message.setBody(xmlStr)
    message.setHeader("Content-Type", "text/xml;charset=UTF-8")
    return message
}

def buildXmlFromJson(builder, obj, String nodeName = "root") {
    if (obj instanceof Map) {
        builder."${nodeName}" {
            obj.each { key, value -> buildXmlFromJson(builder, value, key) }
        }
    } else if (obj instanceof List) {
        obj.each { item -> buildXmlFromJson(builder, item, nodeName) }
    } else {
        builder."${nodeName}"(obj?.toString() ?: "")
    }
}
