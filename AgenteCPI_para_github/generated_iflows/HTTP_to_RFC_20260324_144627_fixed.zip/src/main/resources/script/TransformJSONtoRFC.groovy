import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.xml.MarkupBuilder

def Message processData(Message message) {
    
    // Get message body as JSON
    def body = message.getBody(String.class)
    def jsonSlurper = new JsonSlurper()
    def jsonInput = jsonSlurper.parseText(body)
    
    // Get RFC function name from header
    def rfcFunction = message.getHeader("RFCFunction", String.class)
    if (!rfcFunction) {
        rfcFunction = "Z_RFC_FUNCTION"
    }
    
    // Build RFC XML structure
    def writer = new StringWriter()
    def xml = new MarkupBuilder(writer)
    
    xml.mkp.xmlDeclaration(version: "1.0", encoding: "UTF-8")
    
    xml.'soapenv:Envelope'('xmlns:soapenv': 'http://schemas.xmlsoap.org/soap/envelope/',
                           'xmlns:urn': 'urn:sap-com:document:sap:rfc:functions') {
        'soapenv:Header'()
        'soapenv:Body'() {
            "urn:${rfcFunction}"() {
                // Map JSON fields to RFC parameters
                jsonInput.each { key, value ->
                    if (value instanceof Map) {
                        // Handle nested structures
                        "${key}"() {
                            value.each { subKey, subValue ->
                                "${subKey}"(subValue)
                            }
                        }
                    } else if (value instanceof List) {
                        // Handle tables
                        "${key}"() {
                            value.each { item ->
                                'item'() {
                                    item.each { itemKey, itemValue ->
                                        "${itemKey}"(itemValue)
                                    }
                                }
                            }
                        }
                    } else {
                        // Simple parameters
                        "${key}"(value)
                    }
                }
            }
        }
    }
    
    // Set transformed XML as message body
    message.setBody(writer.toString())
    
    return message
}