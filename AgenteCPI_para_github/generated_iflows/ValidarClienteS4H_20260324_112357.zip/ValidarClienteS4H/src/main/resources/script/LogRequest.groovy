import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap

def Message processData(Message message) {
    def body = message.getBody(String.class)
    def headers = message.getHeaders()
    
    def messageLog = messageLogFactory.getMessageLog(message)
    
    if (messageLog != null) {
        messageLog.addAttachmentAsString("Request_Payload", body, "text/xml")
        messageLog.setStringProperty("Cliente_ID", headers.get("ClienteID") ?: "N/A")
    }
    
    // Guardar información en propiedades para uso posterior
    message.setProperty("OriginalPayload", body)
    message.setProperty("RequestTimestamp", new Date().toString())
    
    return message
}