import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlSlurper
import groovy.xml.MarkupBuilder

def Message processData(Message message) {
    def body = message.getBody(String.class)
    def messageLog = messageLogFactory.getMessageLog(message)
    
    try {
        // Parsear respuesta SOAP
        def soapResponse = new XmlSlurper().parseText(body)
        
        // Extraer datos relevantes de la respuesta
        def validationResult = soapResponse.'**'.find { it.name() == 'ValidacionResultado' }
        def clienteValido = validationResult?.ClienteValido?.text() ?: 'false'
        def mensaje = validationResult?.Mensaje?.text() ?: 'Sin mensaje'
        
        // Construir respuesta JSON
        def writer = new StringWriter()
        def json = new groovy.json.JsonBuilder(writer)
        json {
            status clienteValido == 'true' ? 'SUCCESS' : 'FAILED'
            clienteValido clienteValido
            mensaje mensaje
            timestamp new Date().format("yyyy-MM-dd'T'HH:mm:ss")
        }
        
        message.setBody(writer.toString())
        message.setHeader("Content-Type", "application/json")
        
        if (messageLog != null) {
            messageLog.addAttachmentAsString("Response_Payload", writer.toString(), "application/json")
            messageLog.setStringProperty("ValidationStatus", clienteValido)
        }
        
    } catch (Exception e) {
        if (messageLog != null) {
            messageLog.addAttachmentAsString("Error_Processing_Response", e.getMessage(), "text/plain")
        }
        throw new Exception("Error procesando respuesta SOAP: " + e.getMessage())
    }
    
    return message
}