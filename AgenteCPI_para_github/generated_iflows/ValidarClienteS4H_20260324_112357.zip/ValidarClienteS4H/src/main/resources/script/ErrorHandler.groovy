import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonBuilder

def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message)
    def exception = message.getProperty("CamelExceptionCaught")
    
    def errorMessage = "Error desconocido"
    def errorDetail = ""
    
    if (exception != null) {
        errorMessage = exception.getMessage() ?: exception.toString()
        errorDetail = exception.getClass().getName()
        
        if (messageLog != null) {
            messageLog.addAttachmentAsString("Exception_Details", errorMessage, "text/plain")
            messageLog.setStringProperty("ErrorType", errorDetail)
        }
    }
    
    // Construir respuesta de error en JSON
    def writer = new StringWriter()
    def json = new JsonBuilder(writer)
    json {
        status "ERROR"
        error errorMessage
        errorType errorDetail
        timestamp new Date().format("yyyy-MM-dd'T'HH:mm:ss")
    }
    
    message.setBody(writer.toString())
    message.setHeader("Content-Type", "application/json")
    message.setHeader("CamelHttpResponseCode", "500")
    
    return message
}