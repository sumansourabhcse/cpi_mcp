import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.MarkupBuilder

def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message)
    
    try {
        // Get incoming payload
        def body = message.getBody(String.class)
        
        messageLog.addAttachmentAsString("Original_Payload", body, "text/plain")
        
        // Check if payload is already SOAP envelope
        if (body.contains("soap:Envelope") || body.contains("soapenv:Envelope")) {
            messageLog.setStringProperty("PayloadType", "Already SOAP")
            return message
        }
        
        // Build SOAP 1.1 envelope
        def writer = new StringWriter()
        def xml = new MarkupBuilder(writer)
        
        xml.mkp.xmlDeclaration(version: "1.0", encoding: "UTF-8")
        xml.'soap:Envelope'(
            'xmlns:soap': 'http://schemas.xmlsoap.org/soap/envelope/',
            'xmlns:xsi': 'http://www.w3.org/2001/XMLSchema-instance',
            'xmlns:xsd': 'http://www.w3.org/2001/XMLSchema'
        ) {
            'soap:Header'()
            'soap:Body' {
                mkp.yieldUnescaped(body)
            }
        }
        
        def soapEnvelope = writer.toString()
        
        messageLog.addAttachmentAsString("SOAP_Envelope", soapEnvelope, "text/xml")
        messageLog.setStringProperty("PayloadType", "Transformed to SOAP")
        
        message.setBody(soapEnvelope)
        
    } catch (Exception e) {
        messageLog.addAttachmentAsString("Error_PrepareSOAP", e.getMessage() + "\n" + e.getStackTrace().join("\n"), "text/plain")
        throw new RuntimeException("Error preparing SOAP envelope: " + e.getMessage(), e)
    }
    
    return message
}